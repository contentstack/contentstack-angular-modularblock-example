export const environment = {
  production: true,
  config: {
    api_key: '',
    delivery_token: '',
    environment: '',
    region: ''
  }
};
