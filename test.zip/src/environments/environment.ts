export const environment = {
  production: false,
  config: {
    api_key: 'blt75b5b5703fe3a6b7',
    delivery_token: 'csa47bc2ae897d4a5dbc10fb96',
    environment: 'production',
    region: 'us'
  }
};
